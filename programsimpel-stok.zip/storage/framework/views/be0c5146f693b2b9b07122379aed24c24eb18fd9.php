<?php $__env->startSection('pageTitle', 'Penerimaan Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="box" ng-controller="PenerimaanBarangFormController">
    <form name="frm" ng-submit="save(frm, $event)">
        <div class="box-body">
        </div>
        <div class="box-footer">
            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<?php echo e(route('beli_penerimaan.index')); ?>" class="btn btn-default">Back</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\yonathan\programsimpel-stok\resources\views/beli_penerimaan/form.blade.php ENDPATH**/ ?>