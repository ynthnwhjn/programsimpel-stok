<?php $__env->startSection('pageTitle', 'Gudang'); ?>

<?php $__env->startSection('content'); ?>
<div class="box" ng-controller="PageController">
    <div class="box-header with-border">
        <h3 class="box-title"><?php echo $__env->yieldContent('pageTitle'); ?></h3>
    </div>
    <form name="frm" ng-submit="save(frm, $event)">
        <div class="box-body">
            <fieldset <?php if($action_method == 'show'): ?> disabled <?php endif; ?>>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Nama</label>
                            <input type="text" class="form-control" name="nama" ng-model="formfield.nama">
                        </div>
                    </div>
                </div>
            </fieldset>
        </div>
        <div class="box-footer">
            <?php if($action_method != 'show'): ?>
                <button type="submit" class="btn btn-primary">Save</button>
            <?php endif; ?>
            <a href="<?php echo e(route('gudang.index')); ?>" class="btn btn-default">Back</a>
        </div>
    </form>
</div>

<?php if(isset($item)): ?>
<?= app('\Spatie\BladeJavaScript\Renderer')->render('item', $item); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    (function () {
        'use strict';

        angular.module('programsimpel').controller('PageController', PageController);

        function PageController($scope, $http, $validation, $gridFormValidation, $q) {
            $scope.formfield = {};


            if (window.item) {
                $scope.formfield = item;
            }

            $scope.save = function (formCtrl, evt) {
                var btnSubmit = angular.element(evt.currentTarget).find('button[type="submit"]');
                btnSubmit.prop('disabled', true);
                evt.preventDefault();

                var q1 = $validation.validate(formCtrl),
                    q2 = $gridFormValidation.validate($scope.gridApi);

                $q.all([q1, q2]).then(function () {
                    $scope.formfield.gudang_detail = $scope.gridform1.data;

                    $http({
                        url: '/gudang',
                        method: 'POST',
                        data: $scope.formfield,
                    })
                        .then(function name(response) {
                            console.log(response)

                            if (response.data.redirect_to) {
                                window.location.href = response.data.redirect_to;
                            }

                            btnSubmit.prop('disabled', false);
                        }, function (rejection) {
                            btnSubmit.prop('disabled', false);
                        });
                }, function () {
                    console.log('reject?')
                    btnSubmit.prop('disabled', false);
                });
            }
        }

    })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\yonathan\programsimpel-stok\resources\views/gudang/form.blade.php ENDPATH**/ ?>