<?php $__env->startSection('pageTitle', 'Penerimaan Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-body">
        <a href="<?php echo e(route('beli_penerimaan.create')); ?>" class="btn btn-default">Create</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\yonathan\programsimpel-stok\resources\views/beli_penerimaan/index.blade.php ENDPATH**/ ?>