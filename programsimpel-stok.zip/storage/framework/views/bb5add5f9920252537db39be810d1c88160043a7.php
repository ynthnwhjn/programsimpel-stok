<div input-search="<?php echo e($searchOptions); ?>">
    <input type="text" placeholder="Search..." class="form-control" <?php echo e($attributes); ?> uib-typeahead="item as item.label for item in getItems($viewValue)" typeahead-on-select="onSelect($item, $model, $label, $event)">
</div>
<?php /**PATH D:\yonathan\programsimpel-stok\resources\views/components/input-search.blade.php ENDPATH**/ ?>