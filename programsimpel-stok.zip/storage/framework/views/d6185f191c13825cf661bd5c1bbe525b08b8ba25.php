<?php $__env->startSection('pageTitle', 'Penerimaan Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="box" ng-controller="PageController">
    <div class="box-header with-border">
        <h3 class="box-title"><?php echo $__env->yieldContent('pageTitle'); ?></h3>

        <div class="btn-group">
            <a href="<?php echo e(route('penerimaan_barang.create')); ?>" class="btn btn-default">Create</a>
        </div>
    </div>
    <div class="box-body">
        <table class="table table-hover" datatable dt-options="dtOptions" dt-columns="dtColumns" dt-instance="dtInstance"></table>
        <!-- <table class="table table-hover">
            <thead>
                <tr>
                    <th style="width: 35px;">#</th>
                    <th style="width: 120px;">Kode</th>
                    <th>Tanggal</th>
                    <th>Jenis</th>
                    <th>Gudang</th>
                    <th class="dt-center" style="width: 90px;">
                        <i class="fa fa-bars"></i>
                    </th>
                </tr>
            </thead>
        </table> -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    (function () {
        'use strict';

        angular.module('programsimpel').controller('PageController', PageController);

        function PageController($scope, $uibModal, $http, $validation, DTOptionsBuilder, DTColumnBuilder) {
            $scope.filter = {};
            $scope.dtInstance = {};

            $scope.dtOptions = DTOptionsBuilder.newOptions()
                .withOption('ajax', {
                    dataSrc: 'data',
                    url: route('penerimaan_barang.index'),
                })
                .withOption('processing', true)
                .withOption('serverSide', true);

            $scope.dtColumns = [
                DTColumnBuilder.newColumn(null)
                    .withTitle('#')
                    .withOption('width', 40)
                    .notSortable()
                    .renderWith(function (data, type, row, meta) {
                        return meta.row + 1;
                    }),
                DTColumnBuilder.newColumn('kode').withTitle('Kode'),
                DTColumnBuilder.newColumn('tanggal').withTitle('Tanggal')
                    .renderWith(function (data, type, row, meta) {
                        return moment(data).format('DD-MM-YYYY');
                    }),
                DTColumnBuilder.newColumn('gudang_tujuan.nama').withTitle('Gudang'),
                DTColumnBuilder.newColumn(null).withTitle('<i class="fa fa-bars"></i>')
                    .withOption('width', 90)
                    .withOption('class', 'dt-center')
                    .renderWith(function (data, type, row, meta) {
                        return '<a href="'+ route('penerimaan_barang.edit', row) +'">Edit</a>';
                    }),
            ];
        }
    })();

    $(document).ready(function () {
        console.log(route('penerimaan_barang.index'))

        $('.table1').DataTable({
            processing: true,
            serverSide: true,
            ajax: route('penerimaan_barang.index'),
            columns: [
                {
                    data: 'id',
                    render: function (data, type, row, meta) {
                        return meta.row + 1;
                    }
                },
                { data: 'kode' },
                {
                    data: 'tanggal',
                    render: function (data, type, row, meta) {
                        return moment(data).format('DD-MM-YYYY');
                    }
                },
                { data: 'jenis' },
                {
                    data: 'gudang_tujuan',
                    render: function (data, type, row, meta) {
                        if(data) {
                            return data.nama;
                        }

                        return '';
                    }
                },
                {
                    data: 'actions',
                    className: 'dt-center',
                    orderable: false,
                    render: function (data, type, row, meta) {
                        return '<a href="'+ route('penerimaan_barang.edit', row) +'">Edit</a>';
                    }
                },
            ],
            language: {
                'lengthMenu': '_MENU_',
				'search': '',
				'searchPlaceholder': 'Search',
				'info': '_START_ - _END_ / _TOTAL_',
				'paginate': {
					'previous': '<i class="fa fa-angle-double-left"></i>',
					'next': '<i class="fa fa-angle-double-right"></i>'
				},
            },
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\yonathan\programsimpel-stok\resources\views/penerimaan_barang/index.blade.php ENDPATH**/ ?>