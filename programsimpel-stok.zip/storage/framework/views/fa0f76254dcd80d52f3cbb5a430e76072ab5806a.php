<?php $__env->startSection('pageTitle', 'Penerimaan Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="box" ng-controller="PageController">
    <div class="box-header with-border">
        <h3 class="box-title"><?php echo $__env->yieldContent('pageTitle'); ?></h3>
    </div>
    <form name="frm" ng-submit="save(frm, $event)">
        <div class="box-body">
            <fieldset <?php if($action_method == 'show'): ?> disabled <?php endif; ?>>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Kode</label>
                            <input type="text" readonly placeholder="AUTO" class="form-control" name="kode" ng-model="formfield.kode">
                        </div>

                        <div class="form-group">
                            <label>Tanggal</label>
                            <input type="text" class="form-control" name="tanggal" ng-model="formfield.tanggal" datetimepicker="{'format': 'DD-MM-YYYY'}" validator="required">
                        </div>

                        <div class="form-group">
                            <label>Gudang</label>
                            <?php if (isset($component)) { $__componentOriginalb440d3086a355ca225f8104e1e7e339a01f7c62a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InputSearch::class, ['searchOptions' => 'browseGudang']); ?>
<?php $component->withName('input-search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'gudang_tujuan_nama','ng-model' => 'formfield.gudang_tujuan.nama','validator' => 'required']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb440d3086a355ca225f8104e1e7e339a01f7c62a)): ?>
<?php $component = $__componentOriginalb440d3086a355ca225f8104e1e7e339a01f7c62a; ?>
<?php unset($__componentOriginalb440d3086a355ca225f8104e1e7e339a01f7c62a); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>

                <?php if (isset($component)) { $__componentOriginaldace49824d78d59b4e4f2457864304836f5b2007 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GridForm::class, ['gridOptions' => 'gridform1']); ?>
<?php $component->withName('grid-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldace49824d78d59b4e4f2457864304836f5b2007)): ?>
<?php $component = $__componentOriginaldace49824d78d59b4e4f2457864304836f5b2007; ?>
<?php unset($__componentOriginaldace49824d78d59b4e4f2457864304836f5b2007); ?>
<?php endif; ?>
            </fieldset>
        </div>
        <div class="box-footer">
            <?php if($action_method != 'show'): ?>
                <button type="submit" class="btn btn-primary">Save</button>
            <?php endif; ?>
            <a href="<?php echo e(route('penerimaan_barang.index')); ?>" class="btn btn-default">Back</a>
        </div>
    </form>
</div>

<?php if(isset($item)): ?>
<?= app('\Spatie\BladeJavaScript\Renderer')->render('item', $item); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    (function () {
        'use strict';

        angular.module('programsimpel').controller('PageController', PageController);

        function PageController($scope, $http, $validation, $gridFormValidation, $q) {
            $scope.formfield = {};

            $scope.browseGudang = {
                items: function (viewValue) {
                    console.log(viewValue)

                    return $http.get('/api/browse/gudang', {
                        params: {
                            keyword: viewValue,
                        },
                    });
                },
                onSelect: function (item) {
                    $scope.formfield.gudang_tujuan = item.value;
                    $scope.formfield.gudangtujuan_id = item.value.id;
                },
            };

            $scope.browseBarang = {
                items: function (viewValue) {
                    console.log(viewValue)

                    return $http.get('/api/browse/barang', {
                        params: {
                            keyword: viewValue,
                        },
                    });
                },
                onSelect: function (item, rowEntity) {
                    console.log(item)

                    rowEntity.barang = item.value;
                    rowEntity.barang_id = item.value.id;
                },
            };

            $scope.gridform1 = {
                data: [{}],
                columnDefs: [
                    {
                        name: 'barang_nama',
                        field: 'barang.nama',
                        displayName: 'Barang',
                        editableCellTemplate: 'grid-form/input-search',
                        searchOptions: $scope.browseBarang,
                        validators: {
                            required: true
                        },
                        width: 400,
                    },
                    {
                        name: 'jumlah',
                        field: 'jumlah',
                        cellFilter: 'number',
                        cellClass: 'text-right',
                        validators: {
                            required: true
                        },
                        width: 90,
                    },
                    {
                        name: 'keterangan',
                        field: 'keterangan',
                    },
                ],
            };

            if (window.item) {
                $scope.formfield = item;

                $scope.gridform1.data = item.stok_mutasi_detail;
            }

            $scope.save = function (formCtrl, evt) {
                console.log(form_action)
                var btnSubmit = angular.element(evt.currentTarget).find('button[type="submit"]');
                btnSubmit.prop('disabled', true);
                evt.preventDefault();

                var q1 = $validation.validate(formCtrl),
                    q2 = $gridFormValidation.validate($scope.gridApi);

                $q.all([q1, q2]).then(function () {
                    $scope.formfield.penerimaan_barang_detail = $scope.gridform1.data;

                    $http({
                        url: form_action,
                        method: form_method,
                        data: $scope.formfield,
                    })
                        .then(function name(response) {
                            console.log(response)

                            if (response.data.redirect_to) {
                                window.location.href = response.data.redirect_to;
                            }
                        }, function (rejection) {
                            btnSubmit.prop('disabled', false);
                        });
                }, function () {
                    console.log('reject?')
                    btnSubmit.prop('disabled', false);
                });
            }
        }

    })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\yonathan\programsimpel-stok\resources\views/penerimaan_barang/form.blade.php ENDPATH**/ ?>