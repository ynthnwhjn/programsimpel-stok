<!DOCTYPE html>
<html lang="en" ng-app="programsimpel">
<?php echo $__env->make('shared.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="hold-transition skin-black sidebar-mini fixed">
<div class="wrapper">
    <?php echo $__env->make('shared.main-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('shared.main-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrapper">
        <div class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>

<?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
<?= app('\Spatie\BladeJavaScript\Renderer')->render('form_action', $form_action); ?>
<?= app('\Spatie\BladeJavaScript\Renderer')->render('form_method', $form_method); ?>
<script src="/js/app.js"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<script src="/js/app.components.js"></script>
</body>
</html>
<?php /**PATH D:\yonathan\programsimpel-stok\resources\views/layouts/admin.blade.php ENDPATH**/ ?>