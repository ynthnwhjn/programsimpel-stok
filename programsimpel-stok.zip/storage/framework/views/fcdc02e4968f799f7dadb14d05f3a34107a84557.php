<?php $__env->startSection('content'); ?>
<h1>Welcome, <?php echo e($session_user->name); ?></h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\yonathan\programsimpel-stok\resources\views/welcome.blade.php ENDPATH**/ ?>